"""
Train and save the deep learning model for bone cancer classification.
"""

import os
import torch
import logging
from backend.main import train_deep_model, load_and_preprocess_data

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def train_and_save_models():
    """
    Train and save the deep learning model.
    """
    try:
        # Load and preprocess data
        logger.info("Loading and preprocessing data...")
        X_train, X_test, y_train, y_test, scaler, label_encoders = load_and_preprocess_data()
        
        # Train deep learning model
        logger.info("Training deep learning model...")
        n_classes = len(label_encoders['Treatment'].classes_)
        dl_model = train_deep_model(X_train, y_train, input_size=6, hidden_size=64, output_size=n_classes)
        torch.save(dl_model.state_dict(), 'backend/dl_model.pth')
        logger.info("✅ Deep learning model saved successfully")
        
        logger.info("✅ Model training and saving complete!")
        
    except Exception as e:
        logger.error(f"Error training model: {str(e)}")
        raise

if __name__ == "__main__":
    train_and_save_models()
