"""
Script to delete and regenerate models for bone cancer classification (ML and DL only).
"""

import os
import torch
import logging
from backend.main import train_deep_model, train_classical_model, load_and_preprocess_data

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def delete_existing_models():
    """Delete existing ML and DL model files."""
    model_files = [
        'backend/classical_model.pkl',
        'backend/dl_model.pth',
        'backend/preprocessing.pkl'
    ]
    
    for file in model_files:
        if os.path.exists(file):
            try:
                os.remove(file)
                logger.info(f"Deleted {file}")
            except Exception as e:
                logger.error(f"Error deleting {file}: {str(e)}")

def train_and_save_models():
    """Train and save ML and DL models."""
    try:
        # Load and preprocess data
        logger.info("Loading and preprocessing data...")
        X_train, X_test, y_train, y_test, scaler, label_encoders = load_and_preprocess_data()
        
        # Train classical model
        logger.info("Training classical model...")
        classical_model = train_classical_model(X_train, y_train)
        logger.info("✅ Classical model trained and saved")
        
        # Train deep learning model
        logger.info("Training deep learning model...")
        n_classes = len(label_encoders['Treatment'].classes_)
        dl_model = train_deep_model(X_train, y_train, input_size=6, hidden_size=64, output_size=n_classes)
        logger.info("✅ Deep learning model trained and saved")
        
        logger.info("✅ All models trained and saved successfully!")
        
    except Exception as e:
        logger.error(f"Error training models: {str(e)}")
        raise

if __name__ == "__main__":
    # Delete existing models
    delete_existing_models()
    
    # Train and save new models
    train_and_save_models()
    
    logger.info("✅ Model regeneration complete!")
