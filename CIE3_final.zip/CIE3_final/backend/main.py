# Main Model Implementation Module
# This module contains the implementation of classical and deep learning models.

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from imblearn.over_sampling import SMOTE
import pickle
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import os
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create necessary directories
Path("backend").mkdir(exist_ok=True)
Path("static").mkdir(exist_ok=True)

# Check if models exist, if not train them
def ensure_models_exist():
    model_files = [
        "backend/classical_model.pkl",
        "backend/dl_model.pth"
    ]
    
    if not all(os.path.exists(f) for f in model_files):
        logger.info("Models not found. Training new models...")
        try:
            # Load and preprocess data
            logger.info("Loading and preprocessing data...")
            X_train, X_test, y_train, y_test, scaler, label_encoders = load_and_preprocess_data()
            logger.info(f"Data loaded successfully. Shapes: X_train={X_train.shape}, y_train={y_train.shape}")
            
            # Train classical ML model
            logger.info("Training classical ML model...")
            try:
                classical_model = train_classical_model(X_train, y_train)
                with open("backend/classical_model.pkl", "wb") as f:
                    pickle.dump(classical_model, f)
                logger.info("Classical model saved successfully!")
            except Exception as e:
                logger.error(f"Error training classical model: {str(e)}")
                raise
            
            # Train deep learning model
            logger.info("Training deep learning model...")
            try:
                output_size = len(np.unique(y_train))  # Automatically detect number of output classes
                dl_model = train_deep_model(X_train, y_train, X_train.shape[1], 128, output_size)
                torch.save(dl_model.state_dict(), "backend/dl_model.pth")
                logger.info("Deep learning model saved successfully!")
            except Exception as e:
                logger.error(f"Error training deep learning model: {str(e)}")
                raise

            logger.info("✅ All models trained and saved successfully!")
        
        except Exception as e:
            logger.error(f"Error during model training: {str(e)}")
            raise
    else:
        logger.info("✅ All models found!")

# class DeepNeuralNetwork(nn.Module):
#     def __init__(self, input_size, hidden_size, output_size):
#         super(DeepNeuralNetwork, self).__init__()
#         self.fc1 = nn.Linear(input_size, hidden_size)
#         self.bn1 = nn.BatchNorm1d(hidden_size)
#         self.fc2 = nn.Linear(hidden_size, hidden_size)
#         self.bn2 = nn.BatchNorm1d(hidden_size)
#         self.fc3 = nn.Linear(hidden_size, hidden_size)
#         self.bn3 = nn.BatchNorm1d(hidden_size)
#         self.fc4 = nn.Linear(hidden_size, hidden_size)
#         self.bn4 = nn.BatchNorm1d(hidden_size)
#         self.fc5 = nn.Linear(hidden_size, hidden_size)
#         self.bn5 = nn.BatchNorm1d(hidden_size)
#         self.fc6 = nn.Linear(hidden_size, output_size)
#         self.dropout = nn.Dropout(0.4)
#         self.relu = nn.ReLU()
    
#     def forward(self, x):
#         if len(x.shape) == 1:
#             x = x.unsqueeze(0)
#         x = self.fc1(x)
#         x = self.bn1(x)
#         x = self.relu(x)
#         x = self.dropout(x)

#         x = self.fc2(x)
#         x = self.bn2(x)
#         x = self.relu(x)
#         x = self.dropout(x)

#         x = self.fc3(x)
#         x = self.bn3(x)
#         x = self.relu(x)
#         x = self.dropout(x)

#         x = self.fc4(x)
#         x = self.bn4(x)
#         x = self.relu(x)
#         x = self.dropout(x)

#         x = self.fc5(x)
#         x = self.bn5(x)
#         x = self.relu(x)
#         x = self.dropout(x)

#         x = self.fc6(x)
#         return x
class DeepNeuralNetwork(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(DeepNeuralNetwork, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.ln1 = nn.LayerNorm(hidden_size)  # Use LayerNorm instead of BatchNorm
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.ln2 = nn.LayerNorm(hidden_size)
        self.fc3 = nn.Linear(hidden_size, hidden_size)
        self.ln3 = nn.LayerNorm(hidden_size)
        self.fc4 = nn.Linear(hidden_size, hidden_size)
        self.ln4 = nn.LayerNorm(hidden_size)
        self.fc5 = nn.Linear(hidden_size, hidden_size)
        self.ln5 = nn.LayerNorm(hidden_size)
        self.fc6 = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(0.4)
        self.relu = nn.ReLU()
    
    def forward(self, x):
        if len(x.shape) == 1:
            x = x.unsqueeze(0)
        x = self.fc1(x)
        x = self.ln1(x)
        x = self.relu(x)
        x = self.dropout(x)

        x = self.fc2(x)
        x = self.ln2(x)
        x = self.relu(x)
        x = self.dropout(x)

        x = self.fc3(x)
        x = self.ln3(x)
        x = self.relu(x)
        x = self.dropout(x)

        x = self.fc4(x)
        x = self.ln4(x)
        x = self.relu(x)
        x = self.dropout(x)

        x = self.fc5(x)
        x = self.ln5(x)
        x = self.relu(x)
        x = self.dropout(x)

        x = self.fc6(x)
        return x


def load_and_preprocess_data():
    try:
        logger.info("🔄 Loading dataset...")
        dataset_path = "dataset\Bone Tumor Dataset.csv"
        if not os.path.exists(dataset_path):
            raise FileNotFoundError(f"Dataset file not found at {dataset_path}")
            
        df = pd.read_csv(dataset_path)
        required_columns = ['Age', 'Sex', 'Grade', 'Histological type', 'MSKCC type', 
                          'Site of primary STS', 'Treatment']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")

        label_encoders = {}
        categorical_columns = ['Sex', 'Grade', 'Histological type', 'MSKCC type', 
                             'Site of primary STS', 'Treatment']
        for col in categorical_columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col])
            label_encoders[col] = le
            logger.info(f"Encoded {col} values: {list(le.classes_)}")
        
        X = df[['Age', 'Sex', 'Grade', 'Histological type', 'MSKCC type', 'Site of primary STS']]
        y = df['Treatment']

        smote = SMOTE(random_state=42)
        X_resampled, y_resampled = smote.fit_resample(X, y)

        X_train, X_test, y_train, y_test = train_test_split(
            X_resampled, y_resampled, 
            test_size=0.2, 
            random_state=42, 
            stratify=y_resampled
        )

        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)

        with open("backend/preprocessing.pkl", "wb") as f:
            pickle.dump({
                'scaler': scaler,
                'label_encoders': label_encoders
            }, f)
        
        logger.info("✅ Data preprocessing complete.")
        return X_train_scaled, X_test_scaled, y_train, y_test, scaler, label_encoders
        
    except Exception as e:
        logger.error(f"Error in data preprocessing: {str(e)}")
        raise

def train_classical_model(X_train, y_train):
    model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
    model.fit(X_train, y_train)
    with open('backend/classical_model.pkl', 'wb') as f:
        pickle.dump(model, f)
    return model

def train_deep_model(X_train, y_train, input_size, hidden_size, output_size):
    X_tensor = torch.FloatTensor(X_train)
    y_tensor = torch.LongTensor(y_train)
    model = DeepNeuralNetwork(input_size, hidden_size, output_size)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=3, verbose=True)

    dataset = TensorDataset(X_tensor, y_tensor)
    loader = DataLoader(dataset, batch_size=32, shuffle=True)

    n_epochs = 30
    for epoch in range(n_epochs):
        model.train()
        total_loss = 0
        for X_batch, y_batch in loader:
            optimizer.zero_grad()
            output = model(X_batch)
            loss = criterion(output, y_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        avg_loss = total_loss / len(loader)
        scheduler.step(avg_loss)
        logger.info(f"Epoch {epoch+1}/{n_epochs}, Loss: {avg_loss:.4f}")
    
    return model
