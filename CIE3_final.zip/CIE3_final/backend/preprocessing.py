"""
Data Preprocessing Module for Bone Cancer Classification
This module handles data preprocessing, feature engineering, and label encoding.
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
import pickle
import os

def get_all_possible_values():
    """Return all possible values for each categorical feature"""
    return {
        'Sex': ['Female', 'Male'],
        'Grade': ['High', 'Intermediate'],
        'Histological type': [
            'epithelioid sarcoma',
            'leiomyosarcoma',
            'malignant solitary fibrous tumor',
            'myxofibrosarcoma',
            'myxoid fibrosarcoma',
            'pleiomorphic leiomyosarcoma',
            'pleiomorphic spindle cell undifferentiated',
            'pleomorphic sarcoma',
            'poorly differentiated synovial sarcoma',
            'sclerosing epithelioid fibrosarcoma',
            'synovial sarcoma',
            'undifferentiated - pleiomorphic',
            'undifferentiated pleomorphic liposarcoma'
        ],
        'MSKCC type': ['Leiomyosarcoma', 'MFH', 'Synovial sarcoma'],
        'Site of primary STS': [
            'left biceps',
            'left buttock',
            'left thigh',
            'parascapusular',
            'right buttock',
            'right parascapusular',
            'right thigh'
        ],
        'Treatment': [
            'Radiotherapy + Surgery',
            'Surgery + Chemotherapy',
            'Radiotherapy + Surgery + Chemotherapy'
        ]
    }

def preprocess_data(data_path='dataset/Bone Tumor Dataset.csv'):
    """
    Preprocess the bone cancer dataset.
    
    Args:
        data_path (str): Path to the dataset CSV file
        
    Returns:
        tuple: (X, y, scaler, label_encoders)
            X: Preprocessed features as numpy array
            y: Encoded target variable as numpy array
            scaler: Fitted StandardScaler
            label_encoders: Dictionary of fitted LabelEncoders
    """
    # Load and clean data
    data = pd.read_csv(data_path)
    
    # Initialize label encoders for categorical variables
    label_encoders = {}
    categorical_columns = ['Sex', 'Grade', 'Histological type', 'MSKCC type', 'Site of primary STS', 'Treatment']
    
    # Encode categorical variables
    for col in categorical_columns:
        le = LabelEncoder()
        data[col] = le.fit_transform(data[col])
        label_encoders[col] = le
    
    # Separate features and target
    features = ['Age', 'Sex', 'Grade', 'Histological type', 'MSKCC type', 'Site of primary STS']
    X = data[features].values  # Convert to numpy array
    y = data['Treatment'].values  # Convert to numpy array
    
    # Scale numerical features
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    # Save preprocessing objects
    preprocessing_objects = {
        'scaler': scaler,
        'label_encoders': label_encoders
    }
    
    with open('backend/preprocessing.pkl', 'wb') as f:
        pickle.dump(preprocessing_objects, f)
    
    return X, y, scaler, label_encoders

def save_preprocessing_objects(scaler, label_encoders):
    """
    Save preprocessing objects to disk.
    
    Args:
        scaler: Fitted StandardScaler
        label_encoders: Dictionary of fitted LabelEncoders
    """
    preprocessing_objects = {
        'scaler': scaler,
        'label_encoders': label_encoders
    }
    
    with open('backend/preprocessing.pkl', 'wb') as f:
        pickle.dump(preprocessing_objects, f)

def load_preprocessing_objects():
    """
    Load preprocessing objects from disk.
    
    Returns:
        tuple: (scaler, label_encoders)
            scaler: Fitted StandardScaler
            label_encoders: Dictionary of fitted LabelEncoders
    """
    with open('backend/preprocessing.pkl', 'rb') as f:
        preprocessing_objects = pickle.load(f)
    
    return preprocessing_objects['scaler'], preprocessing_objects['label_encoders']

def get_valid_values():
    """
    Get valid values for each categorical feature.
    
    Returns:
        dict: Dictionary mapping feature names to their valid values
    """
    data = pd.read_csv('dataset/Bone Tumor Dataset.csv')
    
    valid_values = {}
    categorical_columns = ['Sex', 'Grade', 'Histological type', 'MSKCC type', 'Site of primary STS']
    
    for col in categorical_columns:
        valid_values[col] = sorted(data[col].unique().tolist())
    
    return valid_values

def preprocess_input(input_df):
    # Load preprocessing objects
    with open('backend/preprocessing.pkl', 'rb') as f:
        preprocessing = pickle.load(f)
        scaler = preprocessing['scaler']
        label_encoders = preprocessing['label_encoders']
    
    # Validate input values
    possible_values = get_all_possible_values()
    for col in input_df.columns:
        if col in label_encoders:
            value = input_df[col].iloc[0]
            if value not in possible_values[col]:
                raise ValueError(f"Invalid value for {col}. Valid values are: {', '.join(possible_values[col])}")
    
    # Encode categorical features
    for col in input_df.columns:
        if col in label_encoders:
            input_df[col] = label_encoders[col].transform(input_df[col])
    
    # Scale features
    X = input_df.values
    X = scaler.transform(X)
    
    return X 